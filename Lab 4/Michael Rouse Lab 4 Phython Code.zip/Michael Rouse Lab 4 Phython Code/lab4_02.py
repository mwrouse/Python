"""
    Program: lab4_02.py
    Author: Michael Rouse
    Date: 9/12/13
    Description: Counts down from 30 and says blastoff after 1
"""
print("Countdown to blastoff!!")

countDown = 30

while countDown > 0:
    print (countDown)
    countDown -= 1

print ("Blastoff!!")

print ("\n\nDone...")
