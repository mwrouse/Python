"""
    Program: lab4_04.py
    Author: Michael Rouse
    Date: 9/12/13
    Description: Has the user input a sentence and converts it to lowercase.
"""
print("Tell me a sentence and I will convert it to lowercase!\n\n\n")

userSentence = input("Enter a sentence: ")

print("\nHere is your sentence in all lowercase letters:")
print(userSentence.lower())
