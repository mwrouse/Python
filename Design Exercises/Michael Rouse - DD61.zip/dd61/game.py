"""
    Program......: game.py
    Author.......: Michael Rouse
    Date.........: 3/19/14
    Description..: Game module for dd61
"""
from livewires import games, color
from player import *
from monster import *

# Create the window and frame
games.init(screen_width=640, screen_height=480, fps=50)

def play(classType):
    
    # Create and set the background image
    games.screen.background = games.load_image("dd61_background.jpg", transparent=False)
    
    # Create the correct class Type
    if classType == 1:
        player = Knight("knight", image="sprites\knight.png")
    elif classType == 2:
        player = Cleric("Cleric", image="sprites\cleric.png")
    elif classType == 3:
        player = Thief("Thief", image="sprites\sthief.png")
    
    games.screen.add(player)

    
    # Create the Dragon  object
    dragon = Red_Dragon("Dragon", image="sprites\dragon.png") 

    dragon.enemy = player
    player.enemy = dragon
    
    games.screen.add(dragon)
    
    games.screen.mainloop()


# Inform the user if this module has been ran directly
if __name__ == "__main__":
    print("You ran this module directly (and did not 'import' it).")
    input("\n\nPress the enter key to exit.")

