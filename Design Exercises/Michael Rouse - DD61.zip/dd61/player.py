"""
    Program......: player.py
    Author.......: Michael Rouse
    Date.........: 3/19/14
    Description..: Module for player class in dd61
"""
from livewires import games, color
from random import randint

# CLASS ====================================
# Name.........: Player
# Description..: Class for any player
# Syntax.......: Player(name[, minimum HP[, maximum HP]])
# ==========================================
class Player(games.Sprite, object):
    # Combatant initializer
    def __init__(self, name, minHP=3, maxHP=13, classType="Player", image=""):
        super(Player, self).__init__(image=games.load_image(image), x=150, y=350, dx=0, dy=0)
        
        self.name = name.title()
        self.status = "Alive"
        self.health = randint(3, 13)
        self.money = 0
        self.type = classType

        self.enemy = None
        self.moving = False
        self.attacking = False
        self.attackDelay = 0

        # Labels and Variables for Display Controls On the Screen
        self.controlsOnScreen = False
        self.controlsCounter = 0

        self.lblControls_Attack = games.Text(value="a - Attack", size=40, x=100, y=30, color=color.white)
        self.lblControls_Special = games.Text(value="s - Special Ability", size=40, x=155, y=70, color=color.white)
        self.lblControls_Help = games.Text(value="F1 - Help", size=40, x=95, y=110, color=color.white)
        self.lblControls_Exit = games.Text(value="Esc - Exit", size=40, x=100, y=150, color=color.white)
        
        # label for health info
        self.lblHP = games.Text(value="HP: " + str(self.health), size=30, x=self.x, y=self.top - 20, color=color.white)
        games.screen.add(self.lblHP)
        
    # Print the status of the combatant
    def __str__(self):
        statusInfo = "\n  Name: " + self.name + "\nStatus: " + self.status + \
        "\n    HP: " + str(self.health) + "\n  Gold: " + str(self.money)
        
        return statusInfo

    # Display Health above the character
    def update_label(self):
        self.lblHP.value = "Health: " + str(self.health)
        
    # Attack an enemy
    def attack(self, minDamage=1, maxDamage=6):
        # Random amount of damage points (1-6)
        damage = randint(minDamage, maxDamage)
        
        self.enemy.get_hurt(damage) # Do damage to the enemy
        
        # Print information on the attack
        print("\n" + self.name + " does " + str(damage) + " damage to " + self.enemy.name)
    
    # Inflict damage to combatant
    def get_hurt(self,damage):
        self.health -= damage

        if self.health < 1:
            self.health = 0
            self.status = "dead"

    # Update Method
    def update(self):
        """ Display Information When the "F1" key is hit """
        if games.keyboard.is_pressed(games.K_F1) and self.controlsOnScreen == False:
            # Display controls on the screen
            games.screen.add(self.lblControls_Attack)
            games.screen.add(self.lblControls_Special)
            games.screen.add(self.lblControls_Help)
            games.screen.add(self.lblControls_Exit)

            self.controlsOnScreen = True # Set controls on screen
        
        if self.moving:
            if self.x >= 200:
                self.dx = -1
                
            elif self.x <= 149:
                self.dx = 0
                self.moving = False
                self.x = 150

        
    # Perfom this everytime the frame is refreshed
    def tick(self):
        # Display/Remove controls
        if self.controlsOnScreen:
            self.controlsCounter += 1

            if self.controlsCounter >= 250:
                self.controlsCounter = 0
                self.controlsOnScreen = False
                
                # Remove the controls labels
                self.lblControls_Attack.destroy()
                self.lblControls_Special.destroy()
                self.lblControls_Help.destroy()
                self.lblControls_Exit.destroy()

        # Perform the attack delay
        if self.attacking:
            if self.attackDelay < 20:
                self.attackDelay += 1
            else:
                self.attackDelay = 0
                self.attacking = False
                
        self.update_label()
        
                
        
# CLASS ====================================
# Name.........: Cleric
# Description..: Class for any cleric (Player is the derived class)
# Syntax.......: Cleric(name[, minimum HP[, maximum HP]])
# ==========================================
class Cleric(Player):
    # Heal the Cleric
    def special(self):
        heal = (randint(1, 8))
        self.health += (randint(1, 8))
        print("\n" + self.name + " heals himself by " + str(heal) + " health points.")

        
    def update(self):
        if games.keyboard.is_pressed(games.K_a):
            if not self.attacking:
                self.dx = 1
                self.moving = True

                self.attack()
                self.attacking = True
                        
        if games.keyboard.is_pressed(games.K_s):
            if not self.attacking:
                self.special()
                self.attacking = True

        # Do update method for player
        super(Cleric, self).update()



# CLASS ====================================
# Name.........: Knight
# Description..: Class for a knight
# Syntax.......: Knight(name[, minimum HP[, maximum HP]])
# ==========================================
class Knight(Player):
    # Knight's Smite attack
    def special(self):
        damage = randint(12, 20)
        print("\n" + self.name + " does " + str(damage) + " damage to " + self.enemy.name + " using Smite.")
        self.enemy.get_hurt(damage)

    def update(self):
        if games.keyboard.is_pressed(games.K_a):
            if not self.attacking:
                self.dx = 1
                self.moving = True

                self.attack()
                self.attacking = True
                        
        if games.keyboard.is_pressed(games.K_s):
            if not self.attacking:
                self.dx = 1
                self.moving = True

                self.special()
                self.attacking = True

        # Do update method for player
        super(Knight, self).update()


    


# CLASS ====================================
# Name.........: Thief
# Description..: Class for a thief
# Syntax.......: Thief(name[, minimum HP[, maximum HP]])
# ==========================================
class Thief(Player):
    # Thief's Steal
    def special(self):
        stolen = randint(1, 10)
        self.money += stolen
        print("\n" + self.name + " steals " + str(stolen) + " gold pieces.")
    
    def update(self):
        # Get Key Input
        if games.keyboard.is_pressed(games.K_a):
            if not self.attacking:
                self.dx = 1
                self.moving = True

                self.attack()
                self.attacking = True
                        
        if games.keyboard.is_pressed(games.K_s):
            if not self.attacking:
                self.dx = 1
                self.moving = True

                self.special()
                self.attacking = True

        # Do update method for player
        super(Thief, self).update()

# Inform the user if this module has been ran directly
if __name__ == "__main__":
    print("You ran this module directly (and did not 'import' it).")
    input("\n\nPress the enter key to exit.")

